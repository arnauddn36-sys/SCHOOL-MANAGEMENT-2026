-- ============================================================
-- SCHOOL-MANAGEMENT-2026 : Extension de base de données (v2)
-- Exécuter ces requêtes dans l'éditeur SQL de Supabase
-- ============================================================

-- 1. Table des Sessions Utilisateurs (Suivi des connexions)
CREATE TABLE IF NOT EXISTS user_sessions (
    id SERIAL PRIMARY KEY,
    user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(50) NOT NULL CHECK (role IN ('eleve', 'enseignant', 'admin')),
    login_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    logout_at TIMESTAMP WITH TIME ZONE,
    last_ping TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    is_online BOOLEAN DEFAULT TRUE,
    ip_address VARCHAR(45)
);

-- Index pour requêtes rapides du Dashboard
CREATE INDEX IF NOT EXISTS idx_user_sessions_online ON user_sessions(is_online, last_ping);

-- 2. Table de Gestion des Présences & Absences
CREATE TABLE IF NOT EXISTS attendance (
    id SERIAL PRIMARY KEY,
    student_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    class_id INT NOT NULL,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    status VARCHAR(20) NOT NULL CHECK (status IN ('present', 'absent', 'retard', 'excuse')),
    reason TEXT,
    recorded_by INT REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, date, class_id)
);

-- 3. Table des Emplois du Temps
CREATE TABLE IF NOT EXISTS timetables (
    id SERIAL PRIMARY KEY,
    class_id INT NOT NULL,
    subject_name VARCHAR(100) NOT NULL,
    teacher_id INT REFERENCES users(id) ON DELETE SET NULL,
    room VARCHAR(50) NOT NULL,
    day_of_week INT CHECK (day_of_week BETWEEN 1 AND 7), -- 1: Lundi, 7: Dimanche
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    term VARCHAR(20) DEFAULT 'Trimestre 1'
);

-- 4. Table des Annonces & Communications
CREATE TABLE IF NOT EXISTS announcements (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    author_id INT REFERENCES users(id) ON DELETE SET NULL,
    target_role VARCHAR(20) DEFAULT 'all' CHECK (target_role IN ('all', 'eleve', 'enseignant', 'admin')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Table de Messagerie Interne
CREATE TABLE IF NOT EXISTS internal_messages (
    id SERIAL PRIMARY KEY,
    sender_id INT REFERENCES users(id) ON DELETE CASCADE,
    receiver_id INT REFERENCES users(id) ON DELETE CASCADE,
    subject VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- SÉCURISATION VIA ROW LEVEL SECURITY (RLS) SUPABASE
-- ============================================================
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE timetables ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE internal_messages ENABLE ROW LEVEL SECURITY;

-- Politiques de lecture sécurisées
CREATE POLICY "Utilisateurs authentifiés lisent les annonces" ON announcements FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Consultation des emplois du temps" ON timetables FOR SELECT USING (auth.role() = 'authenticated');
