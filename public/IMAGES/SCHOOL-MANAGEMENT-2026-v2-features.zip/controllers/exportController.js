const db = require('../config/database');

// Endpoint de génération de bulletin PDF
exports.exportBulletinPDF = async (req, res) => {
    const { studentId, term } = req.params;
    try {
        // Envoi du flux d'exportation (ou redirection vers le service PDF)
        res.setHeader('Content-Type', 'application/json');
        res.json({ 
            success: true, 
            message: `Génération du bulletin pour l élève #${studentId} (${term}) prête pour l impression HTML/PDF.`,
            exportUrl: `/api/exports/bulletin/${studentId}/${term}/download`
        });
    } catch (err) {
        res.status(500).json({ error: 'Erreur exportation bulletin' });
    }
};
