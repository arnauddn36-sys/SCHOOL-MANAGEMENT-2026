const db = require('../config/database');

// Enregistrer le début de session (Login)
exports.recordLogin = async (req, res) => {
    const { userId, role } = req.user;
    const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    try {
        const query = `
            INSERT INTO user_sessions (user_id, role, ip_address)
            VALUES ($1, $2, $3)
            RETURNING id, login_at;
        `;
        const { rows } = await db.query(query, [userId, role, ipAddress]);
        res.json({ success: true, sessionId: rows[0].id, loginAt: rows[0].login_at });
    } catch (err) {
        console.error('Erreur recordLogin:', err);
        res.status(500).json({ error: 'Erreur lors de l enregistrement de la session' });
    }
};

// Enregistrer la fin de session (Logout)
exports.recordLogout = async (req, res) => {
    const { sessionId } = req.body;
    try {
        await db.query(
            `UPDATE user_sessions SET logout_at = CURRENT_TIMESTAMP, is_online = FALSE WHERE id = $1`,
            [sessionId]
        );
        res.json({ success: true, message: 'Déconnexion enregistrée' });
    } catch (err) {
        res.status(500).json({ error: 'Erreur déconnexion' });
    }
};

// Pulse Heartbeat (maintenir l'état en ligne)
exports.pingSession = async (req, res) => {
    const { sessionId } = req.body;
    try {
        await db.query(
            `UPDATE user_sessions SET last_ping = CURRENT_TIMESTAMP, is_online = TRUE WHERE id = $1`,
            [sessionId]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: 'Erreur ping' });
    }
};

// Obtenir la liste des utilisateurs connectés & récents
exports.getActiveSessions = async (req, res) => {
    try {
        // Marquer hors ligne les sessions inactives depuis plus de 2 minutes
        await db.query(`
            UPDATE user_sessions 
            SET is_online = FALSE 
            WHERE is_online = TRUE AND last_ping < NOW() - INTERVAL '2 minutes'
        `);

        const query = `
            SELECT 
                s.id as session_id,
                u.nom,
                u.prenom,
                s.role,
                s.login_at,
                s.logout_at,
                s.is_online,
                s.ip_address
            FROM user_sessions s
            JOIN users u ON s.user_id = u.id
            ORDER BY s.is_online DESC, s.login_at DESC
            LIMIT 50;
        `;
        const { rows } = await db.query(query);
        res.json(rows);
    } catch (err) {
        console.error('Erreur getActiveSessions:', err);
        res.status(500).json({ error: 'Erreur de récupération des sessions' });
    }
};
