const db = require('../config/database');

exports.getAnnouncements = async (req, res) => {
    const userRole = req.user ? req.user.role : 'all';
    try {
        const query = `
            SELECT a.*, u.nom as author_nom, u.prenom as author_prenom
            FROM announcements a
            LEFT JOIN users u ON a.author_id = u.id
            WHERE a.target_role = 'all' OR a.target_role = $1
            ORDER BY a.created_at DESC
            LIMIT 20;
        `;
        const { rows } = await db.query(query, [userRole]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Erreur chargement annonces' });
    }
};

exports.createAnnouncement = async (req, res) => {
    const { title, content, targetRole } = req.body;
    const authorId = req.user.userId;
    try {
        const query = `
            INSERT INTO announcements (title, content, author_id, target_role)
            VALUES ($1, $2, $3, $4) RETURNING *;
        `;
        const { rows } = await db.query(query, [title, content, authorId, targetRole || 'all']);
        res.json({ success: true, announcement: rows[0] });
    } catch (err) {
        res.status(500).json({ error: 'Erreur création annonce' });
    }
};
