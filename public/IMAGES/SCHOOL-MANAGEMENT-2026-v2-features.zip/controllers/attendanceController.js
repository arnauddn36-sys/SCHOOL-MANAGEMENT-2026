const db = require('../config/database');

// Saisir ou mettre à jour la présence
exports.saveAttendance = async (req, res) => {
    const { records, classId, date } = req.body; // records = [{ studentId, status, reason }]
    const teacherId = req.user.userId;

    try {
        await db.query('BEGIN');
        for (const rec of records) {
            const query = `
                INSERT INTO attendance (student_id, class_id, date, status, reason, recorded_by)
                VALUES ($1, $2, $3, $4, $5, $6)
                ON CONFLICT (student_id, date, class_id) 
                DO UPDATE SET status = EXCLUDED.status, reason = EXCLUDED.reason, recorded_by = EXCLUDED.recorded_by;
            `;
            await db.query(query, [rec.studentId, classId, date, rec.status, rec.reason || '', teacherId]);
        }
        await db.query('COMMIT');
        res.json({ success: true, message: 'Présences enregistrées avec succès' });
    } catch (err) {
        await db.query('ROLLBACK');
        console.error(err);
        res.status(500).json({ error: 'Erreur lors de l enregistrement des présences' });
    }
};

// Consulter les présences par classe et date
exports.getAttendanceByClass = async (req, res) => {
    const { classId, date } = req.query;
    try {
        const query = `
            SELECT a.id, u.id as student_id, u.nom, u.prenom, COALESCE(a.status, 'non_renseigne') as status, a.reason
            FROM users u
            LEFT JOIN attendance a ON u.id = a.student_id AND a.class_id = $1 AND a.date = $2
            WHERE u.role = 'eleve' AND u.class_id = $1
            ORDER BY u.nom, u.prenom;
        `;
        const { rows } = await db.query(query, [classId, date]);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Erreur chargement présences' });
    }
};
