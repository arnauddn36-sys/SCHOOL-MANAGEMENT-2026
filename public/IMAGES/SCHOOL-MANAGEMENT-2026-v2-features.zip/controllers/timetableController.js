const db = require('../config/database');

exports.getTimetable = async (req, res) => {
    const { classId, teacherId } = req.query;
    try {
        let query = `
            SELECT t.*, u.nom as teacher_nom, u.prenom as teacher_prenom
            FROM timetables t
            LEFT JOIN users u ON t.teacher_id = u.id
        `;
        let params = [];
        if (classId) {
            query += ` WHERE t.class_id = $1`;
            params.push(classId);
        } else if (teacherId) {
            query += ` WHERE t.teacher_id = $1`;
            params.push(teacherId);
        }
        query += ` ORDER BY t.day_of_week, t.start_time;`;

        const { rows } = await db.query(query, params);
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: 'Erreur chargement emploi du temps' });
    }
};

exports.addSlot = async (req, res) => {
    const { classId, subjectName, teacherId, room, dayOfWeek, startTime, endTime, term } = req.body;
    try {
        const query = `
            INSERT INTO timetables (class_id, subject_name, teacher_id, room, day_of_week, start_time, end_time, term)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *;
        `;
        const { rows } = await db.query(query, [classId, subjectName, teacherId, room, dayOfWeek, startTime, endTime, term]);
        res.json({ success: true, slot: rows[0] });
    } catch (err) {
        res.status(500).json({ error: 'Erreur ajout créneau' });
    }
};
