// Module Frontend de suivi des sessions et utilisateurs connectés
let currentSessionId = localStorage.getItem('sessionId');

// Initialiser le Heartbeat (Ping) toutes les 30 secondes
function startSessionHeartbeat() {
    if (!currentSessionId) return;
    
    setInterval(async () => {
        try {
            await fetch('/api/sessions/ping', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ sessionId: currentSessionId })
            });
        } catch (err) {
            console.warn('Heartbeat failed:', err);
        }
    }, 30000);
}

// Charger et afficher le tableau des utilisateurs connectés dans le Dashboard
async function renderActiveSessionsTable(containerId = 'active-sessions-container') {
    const container = document.getElementById(containerId);
    if (!container) return;

    try {
        const response = await fetch('/api/sessions/active');
        const sessions = await response.json();

        let html = `
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-people-fill me-2"></i>Utilisateurs Connectés & Activités Récents</h5>
                    <button class="btn btn-sm btn-light" onclick="renderActiveSessionsTable('${containerId}')"><i class="bi bi-arrow-clockwise"></i> Actualiser</button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Utilisateur</th>
                                    <th>Rôle</th>
                                    <th>Statut</th>
                                    <th>Date & Heure de Connexion</th>
                                    <th>Date & Heure de Déconnexion</th>
                                    <th>Adresse IP</th>
                                </tr>
                            </thead>
                            <tbody>
        `;

        if (sessions.length === 0) {
            html += `<tr><td colspan="6" class="text-center py-3 text-muted">Aucune session enregistrée</td></tr>`;
        } else {
            sessions.forEach(s => {
                const loginDate = new Date(s.login_at).toLocaleString('fr-FR');
                const logoutDate = s.logout_at ? new Date(s.logout_at).toLocaleString('fr-FR') : (s.is_online ? 'Session active' : 'Déconnecté');
                const statusBadge = s.is_online 
                    ? `<span class="badge bg-success"><i class="bi bi-circle-fill me-1 small"></i> En ligne</span>`
                    : `<span class="badge bg-secondary">Hors ligne</span>`;
                
                const roleBadge = s.role === 'admin' 
                    ? `<span class="badge bg-danger">Admin</span>`
                    : (s.role === 'enseignant' ? `<span class="badge bg-info text-dark">Enseignant</span>` : `<span class="badge bg-primary">Élève</span>`);

                html += `
                    <tr>
                        <td class="fw-bold">${s.nom} ${s.prenom}</td>
                        <td>${roleBadge}</td>
                        <td>${statusBadge}</td>
                        <td><small>${loginDate}</small></td>
                        <td><small>${logoutDate}</small></td>
                        <td><code>${s.ip_address || '127.0.0.1'}</code></td>
                    </tr>
                `;
            });
        }

        html += `
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        container.innerHTML = html;
    } catch (err) {
        container.innerHTML = `<div class="alert alert-danger">Erreur lors de la récupération des sessions.</div>`;
    }
}

// Auto-rafraîchissement du tableau toutes les 15 secondes si l'élément est présent
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('active-sessions-container')) {
        renderActiveSessionsTable();
        setInterval(() => renderActiveSessionsTable(), 15000);
    }
    startSessionHeartbeat();
});
