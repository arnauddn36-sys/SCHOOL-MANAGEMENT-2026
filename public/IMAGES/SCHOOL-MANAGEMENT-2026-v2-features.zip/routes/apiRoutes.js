const express = require('express');
const router = express.Router();

const sessionCtrl = require('../controllers/sessionController');
const attendanceCtrl = require('../controllers/attendanceController');
const timetableCtrl = require('../controllers/timetableController');
const announcementCtrl = require('../controllers/announcementController');
const exportCtrl = require('../controllers/exportController');

// Middleware fictif d'authentification à adapter avec votre JWT/Session
const authenticate = (req, res, next) => {
    // Injecte des valeurs par défaut si non défini
    if (!req.user) {
        req.user = { userId: req.headers['x-user-id'] || 1, role: req.headers['x-user-role'] || 'admin' };
    }
    next();
};

// 1. Suivi des Sessions
router.post('/sessions/login', authenticate, sessionCtrl.recordLogin);
router.post('/sessions/logout', sessionCtrl.recordLogout);
router.post('/sessions/ping', sessionCtrl.pingSession);
router.get('/sessions/active', authenticate, sessionCtrl.getActiveSessions);

// 2. Présences
router.post('/attendance/save', authenticate, attendanceCtrl.saveAttendance);
router.get('/attendance', authenticate, attendanceCtrl.getAttendanceByClass);

// 3. Emplois du Temps
router.get('/timetables', authenticate, timetableCtrl.getTimetable);
router.post('/timetables/slot', authenticate, timetableCtrl.addSlot);

// 4. Annonces
router.get('/announcements', authenticate, announcementCtrl.getAnnouncements);
router.post('/announcements', authenticate, announcementCtrl.createAnnouncement);

// 5. Exports
router.get('/exports/bulletin/:studentId/:term', authenticate, exportCtrl.exportBulletinPDF);

module.exports = router;
